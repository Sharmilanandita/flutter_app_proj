import 'package:flutter/material.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:shopping_app/users/authentication/login_screen.dart';
import 'package:shopping_app/users/fragements/dashboard_of_fragements.dart';
import 'package:shopping_app/users/userPreferences/user_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'CLoths app',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: FutureBuilder(
        future: RememberUserPrefs.readUserInfo(),
          builder: (context,dataSnapShot){
        if(dataSnapShot.data == null)
        {
          return LoginScreen();
        }
        else
        {
          return DashboardOfFragements();
        }
      })
    );
  }
}

