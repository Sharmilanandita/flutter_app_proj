import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shopping_app/users/order/order_details.dart';

import '../../api_connection/api_connection.dart';
import '../users/model/order.dart';
import '../users/userPreferences/current_user.dart';

class AdminGetAllOrderScreen extends StatelessWidget {

  final currentOnlineUser = Get.put(CurrentUser());
  Future<List<Order>> getAllOrdersList() async
  {
    List<Order> ordersList = [];
    try
    {
      var res = await http.post(Uri.parse(API.adminGetAllOrders),
        body: {

        },
      );
      if(res.statusCode == 200)
      {

        var responseBodyOfAllOrdersItems = jsonDecode(res.body);
        if(responseBodyOfAllOrdersItems["success"] == true)
        {
          print("hello-------------->");
          (responseBodyOfAllOrdersItems["allOrdersData"] as List).forEach((eachRecord) {
            ordersList.add(Order.fromJson(eachRecord));
          });

        }

      }
      else
      {
        Fluttertoast.showToast(msg: "Status code is not 200");
      }

    }
    catch(e)
    {
      Fluttertoast.showToast(msg:"Error:: " + e.toString());
    }

    return ordersList;
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:EdgeInsets.fromLTRB(16, 24, 8, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset("assets/images/orders_icon.png", width: 140,),
                    Text(
                      "My New Orders",
                      style: TextStyle(
                          fontSize: 24,
                          color: Colors.purpleAccent,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                  ],
                ),

                      ],
                    ),
                  ),




          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: Text(
              "Here are your successfully placed orders.",
              style: TextStyle(
                fontSize: 16,
                color: Colors.white,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
          Expanded(child: displayOrdersList(context),),

        ],
      ),
    );
  }

  displayOrdersList(context)
  {
    return FutureBuilder(
      future: getAllOrdersList(),
      builder: (context, AsyncSnapshot<List<Order>> dataSnapShot)
      {
        if(dataSnapShot.connectionState == ConnectionState.waiting)
        {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Text(
                  "Connection Waiting...",
                  style: TextStyle(color:Colors.grey),
                ),
              ),
              Center(
                child: CircularProgressIndicator(),
              ),
            ],
          );
        }
        if(dataSnapShot.data == null)
        {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Text(
                  "No Orders found yet...",
                  style: TextStyle(color:Colors.grey),
                ),
              ),

            ],
          );
        }
        if(dataSnapShot.data!.length > 0)
        {
          List<Order> eachOrderListInfo = dataSnapShot.data!;
          return ListView.separated(
            padding: EdgeInsets.all(16),
            separatorBuilder:(context, index)
            {
              return Divider(
                height: 1,
                thickness: 1,
              );
            },
            itemCount: eachOrderListInfo.length,
            itemBuilder: (context, index)
            {
              Order eachOrderData = eachOrderListInfo[index];
              return Card(
                  color: Colors.white24,
                  child: Padding(
                    padding: EdgeInsets.all(18),
                    child: ListTile(
                      onTap: (){
                        Get.to(OrderDetailsScreen(
                          clickedOrdersInfo:eachOrderData,
                        ));
                      },
                      title: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Order ID #" + eachOrderData.order_id.toString(),
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                              fontWeight: FontWeight.bold,

                            ),
                          ),

                          Text(
                            "Amount: \$ " + eachOrderData.totalAmount.toString(),
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.purpleAccent,
                              fontWeight: FontWeight.bold,

                            ),
                          ),
                        ],
                      ),
                      trailing: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                DateFormat(
                                    "dd MMMM, YYYY"
                                ).format(eachOrderData.dateTime!),
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                              SizedBox(height:4),
                              Text(
                                DateFormat(
                                    "hh:mm a"
                                ).format(eachOrderData.dateTime!),
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 6,),
                          Icon(
                            Icons.navigate_next,
                            color: Colors.purpleAccent,
                          ),
                        ],
                      ),
                    ),
                  )
              );
            },

          );

        }
        else
        {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Text(
                  "Nothing to show...",
                  style: TextStyle(color:Colors.grey),
                ),
              ),

            ],
          );
        }
      },
    );
  }
}