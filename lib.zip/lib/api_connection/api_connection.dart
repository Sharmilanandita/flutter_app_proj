class API
{
  static const hostConnect="http://192.168.71.204/api_clothes_store";
  static const hostConnectUser="$hostConnect/user";
  static const hostConnectAdmin="$hostConnect/admin";
  static const hostItems="$hostConnect/items";
  static const hostClothes="$hostConnect/clothes";
  static const hostCart="$hostConnect/cart";
  static const hostFavorite="$hostConnect/favorite";
  static const hostOrder="$hostConnect/order";
  static const hostImages="$hostConnect/transactions_proof_images/";

  static const signUp="$hostConnectUser/signup.php";
  static const validateEmail="$hostConnectUser/validate_email.php";
  static const login="$hostConnectUser/login.php";

  static const adminLogin="$hostConnectAdmin/login.php";
  static const adminGetAllOrders="$hostConnectAdmin/read_orders.php";


  static const uploadNewItems = "$hostItems/upload.php";
  static const searchItems = "$hostItems/search.php";

  static const getTrendingMostPopularClothes = "$hostClothes/trending.php";
  static const getAllClothes = "$hostClothes/all.php";


  static const addToCart = "$hostCart/add.php";
  static const getCartList = "$hostCart/read.php";
  static const deleteSelectedItemsFromCartList = "$hostCart/delete.php";
  static const updateItemInCartList = "$hostCart/update.php";

  static const addFavorite = "$hostFavorite/add.php";
  static const deleteFavorite = "$hostFavorite/delete.php";
  static const validateFavorite = "$hostFavorite/validate_favorite.php";
  static const readFavorite = "$hostFavorite/read.php";


  static const addOrder = "$hostOrder/add.php";
  static const readOrders = "$hostOrder/read.php";
  static const updateStatus = "$hostOrder/update_status.php";
  static const readHistory = "$hostOrder/read_history.php";

}