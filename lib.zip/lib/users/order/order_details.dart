import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shopping_app/api_connection/api_connection.dart';
import 'package:http/http.dart' as http;

import '../model/order.dart';


class OrderDetailsScreen extends StatefulWidget {
  final Order? clickedOrdersInfo;

  OrderDetailsScreen({this.clickedOrdersInfo});
  @override
  State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {
  RxString _status = "new".obs;
  String get status => _status.value;
  updateParcelStatusForUi(String parcelReceived)
  {
    _status.value = parcelReceived;
  }
@override
  void initState() {
    // TODO: implement initState
    super.initState();
    updateParcelStatusForUi(widget.clickedOrdersInfo!.status.toString());

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          DateFormat("dd MMMM, yyyy - hh:mm a").format(widget.clickedOrdersInfo!.dateTime!),
          style: TextStyle(fontSize: 14),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.fromLTRB(8, 8, 16, 8),
            child:Material(
              color: Colors.white30,
              borderRadius: BorderRadius.circular(10),
              child: InkWell(
                onTap: (){
                  if(status == "new") {
                    showDialogForParcelConfirmation();
                  }
                },
                borderRadius: BorderRadius.circular(10),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16,vertical: 4),
                  child: Row(
                    children: [
                      Text(
                        "Received",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color:Colors.white,
                        ),
                      ),
                      const SizedBox(width:8),
                      Obx(()=>
                      status == "new" ?
                          Icon(Icons.help_outline,color: Colors.redAccent,)
                          : Icon(Icons.check_circle_outline,color: Colors.greenAccent,)

                      ),
                    ],
                  ),
                ),
              ),

            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding:EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                displayClickedOrderItems(),
              const SizedBox(height:16),
              showTitleText("Phone Number:"),
              const SizedBox(height:8),
              showContentText(widget.clickedOrdersInfo!.phoneNumber!),
              const SizedBox(height:26),
              showTitleText("Shipment Address:"),
              const SizedBox(height:8),
              showContentText(widget.clickedOrdersInfo!.shipmentAddress!),
              const SizedBox(height:26),
              showTitleText("Delivery System:"),
              const SizedBox(height:8),
              showContentText(widget.clickedOrdersInfo!.deliverySystem!),
              const SizedBox(height:26),
              showTitleText("Payment System:"),
              const SizedBox(height:8),
              showContentText(widget.clickedOrdersInfo!.paymentSystem!),
              const SizedBox(height:26),
              showTitleText("Note:"),
              const SizedBox(height:8),
              showContentText(widget.clickedOrdersInfo!.note!),
              const SizedBox(height:26),
              showTitleText("Total Amount:"),
              const SizedBox(height:8),
              showContentText(widget.clickedOrdersInfo!.totalAmount.toString()),
              const SizedBox(height:26),
              showTitleText("Proof of Payment/Transaction:"),
              const SizedBox(height:8),
              FadeInImage(
                width: MediaQuery.of(context).size.width * 0.8,
                fit: BoxFit.fitWidth,
                placeholder: AssetImage(
                    'assets/images/place_holder.png'),
                image: NetworkImage(
                  API.hostImages + widget.clickedOrdersInfo!.image!,
                ),
                imageErrorBuilder: (context, error,
                    stackTraceError) {
                  return Center(
                    child: Icon(Icons.broken_image_outlined),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
  showDialogForParcelConfirmation() async
  {
    if(widget.clickedOrdersInfo!.status == "new")
    {
      var response = await Get.dialog(
        AlertDialog(
          backgroundColor: Colors.black,
          title: Text(
            'Confirmation',
            style: TextStyle(
              color: Colors.grey,

            ),
          ),
          content: Text(
            "Have you received your parcel?",
            style: TextStyle(
              color: Colors.grey,

            ),
          ),
          actions: [
            TextButton(
              onPressed: (){
                Get.back();
              },
              child: Text(
                "No",
                style: TextStyle(
                  color: Colors.redAccent,
                ),
              ),
            ),
            TextButton(
              onPressed: (){
                Get.back(result: "yesConfirmed");
              },
              child: Text(
                "Yes",
                style: TextStyle(
                  color: Colors.green,
                ),
              ),
            ),
          ],
        ),
      );
      if(response == "yesConfirmed")
        {
          updateStatusValueInDatabase();
        }
    }
  }

  updateStatusValueInDatabase() async
  {
      try
      {
          var response = await http.post(Uri.parse(API.updateStatus),
          body:
              {
                "order_id" : widget.clickedOrdersInfo!.order_id.toString(),
              }
          );
          if(response.statusCode == 200)
          {
            var responseForUpdateStatus = jsonDecode(response.body);
            if(responseForUpdateStatus["success"] == true)
            {
              updateParcelStatusForUi("received");

            }

          }  
      }
      catch(e)
      {
        Fluttertoast.showToast(msg: "Error:: " + e.toString());
      }
  }

 Widget showTitleText(String titleText)
  {
    return Text(
      titleText,
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.grey,
      ),
    );
  }

  Widget showContentText(String contentText)
  {
    return Text(
      contentText,
      style: TextStyle(
        fontSize: 14,
        color: Colors.white38,
      ),
    );
  }
  Widget displayClickedOrderItems()
  {

    List<String> clickedOrderItemsInfo = widget.clickedOrdersInfo!.selectedItems!.split("||");
    return Column(
      children: List.generate(clickedOrderItemsInfo.length, (index) {
        Map<String,dynamic> itemInfo = jsonDecode(clickedOrderItemsInfo![index]);
        return Container(
          margin: EdgeInsets.fromLTRB(
            16,
            index == 0?16:8,
            16,
            index == clickedOrderItemsInfo.length-1?16:8,
          ),
          decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  offset: Offset(0,0),
                  blurRadius: 6,
                  color: Colors.black,
                ),
              ]
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.only(

                  topLeft: Radius.circular(20),
                  bottomLeft: Radius.circular(20),
                ),
                child: FadeInImage(
                  height: 150,
                  width: 130,
                  fit: BoxFit.cover,
                  placeholder: AssetImage(
                      'assets/images/place_holder.png'),
                  image: NetworkImage(
                    itemInfo["image"],
                  ),
                  imageErrorBuilder: (context, error,
                      stackTraceError) {
                    return Center(
                      child: Icon(Icons.broken_image_outlined),
                    );
                  },
                ),
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        itemInfo["name"],
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height:16,),
                      Text(
                        itemInfo["size"]
                            .replaceAll("[", "")
                            .replaceAll("]", "") + "\n" +
                            itemInfo["color"]
                                .replaceAll("[", "")
                                .replaceAll("]", ""),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height:16,),
                      Text(
                        "\$ " + itemInfo["totalAmount"].toString(),
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.purpleAccent,
                          fontWeight: FontWeight.bold,

                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Q: ' + itemInfo["quantity"].toString(),
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.purpleAccent,
                  ),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
