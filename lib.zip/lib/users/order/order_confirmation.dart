import 'dart:convert';
import 'dart:core';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:shopping_app/api_connection/api_connection.dart';
import 'package:shopping_app/users/fragements/dashboard_of_fragements.dart';
import 'package:shopping_app/users/fragements/home_fragements_screen.dart';
import 'package:shopping_app/users/userPreferences/current_user.dart';
import 'package:http/http.dart' as http;
import '../model/order.dart';

class OrderConfirmationScreen extends StatelessWidget {
  final ImagePicker _picker = ImagePicker();
  final List<int>? selectedCartIDs;
  final List<Map<String,dynamic>>? selectedCartListItemsInfo;
  final double? totalAmount;
  final String? deliverySystem;
  final String? paymentSystem;
  final String? phoneNumber;
  final String? shipmentAddress;
  final String? note;

  OrderConfirmationScreen({
    this.selectedCartIDs,
    this.selectedCartListItemsInfo,
    this.totalAmount,
    this.deliverySystem,
    this.paymentSystem,
    this.phoneNumber,
    this.shipmentAddress,
    this.note,
});

  RxList<int> _imageSelectedByte = <int>[].obs;
  Uint8List get imageSelectedByte => Uint8List.fromList(_imageSelectedByte);
  RxString  _imageSelectedName = "".obs;
  String get imageSelectedName => _imageSelectedName.value;
  CurrentUser currentUser = Get.put(CurrentUser());

  setSelectedImage(Uint8List selectedImage)
  {
    _imageSelectedByte.value = selectedImage;
  }

  setSelectedImageName(String selectedImageName)
  {
    _imageSelectedName.value = selectedImageName;
  }
  chooseImageFromGallery() async
  {
    final pickedImageXFile = await _picker.pickImage(source: ImageSource.gallery);
    if(pickedImageXFile!=null)
    {
      final bytesOfImage = await pickedImageXFile.readAsBytes();
      setSelectedImage(bytesOfImage);
      setSelectedImageName(path.basename(pickedImageXFile.path));
    }

  }

  saveNewOrderInfo() async
  {
    String selectedItemsString = selectedCartListItemsInfo!.map((e)=>jsonEncode(e)).toList().join("||");
    Order order = Order(
      order_id: 1,
      user_id: currentUser.user.user_id,
      selectedItems: selectedItemsString,
      deliverySystem: deliverySystem,
      paymentSystem: paymentSystem,
      note: note,
      totalAmount: totalAmount,
      image:DateTime.now().microsecondsSinceEpoch.toString() + "-" + imageSelectedName,
      status: "new",
      shipmentAddress: shipmentAddress,
      phoneNumber: phoneNumber,
    );
    try
    {
      var res = await http.post(Uri.parse(API.addOrder),
      body: order.toJson(base64Encode(imageSelectedByte)),
      );
      if(res.statusCode == 200)
      {
        var responseBodyOfAddNewOrder = jsonDecode(res.body);
        
        if(responseBodyOfAddNewOrder["success"] == true)
        {
          
          //delete the selected items from cart list
          selectedCartIDs!.forEach((eachRecord) {
              deleteSelectedItemsFromUserCartList(eachRecord);
          });

        }
        else
        {
          Fluttertoast.showToast(msg: "Error:: Your new order is not placed successfully.");
        }  
      }
    }
    catch(e)
    {
      Fluttertoast.showToast(msg: "Error:: " + e.toString());
    }
  }

  deleteSelectedItemsFromUserCartList(int cartID) async
  {
    try
    {
      var res = await http.post(Uri.parse(API.deleteSelectedItemsFromCartList),
          body: {
            "cart_id":cartID.toString(),
          }
      );
      if(res.statusCode == 200)
      {
        var responseBodyFromDeleteCart = jsonDecode(res.body);
        if(responseBodyFromDeleteCart["success"] == true)
        {
          Fluttertoast.showToast(msg: "Your new order is placed and ordered items deleted from cart list.");
          Get.to(DashboardOfFragements());
        }
      }
      else
      {
        Fluttertoast.showToast(msg: "Error, Status code is not 200.");
      }
    }
    catch(e)
    {
      print("Error:: " + e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.black,
      body:SafeArea(

      child: SingleChildScrollView(
        child:Center(
        child:Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
              Image.asset("assets/images/transaction.png",
              width: 160,
              ),
            const SizedBox(height:4,),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                'Please attach Transaction \nproof ScreenShot / Image',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height:30),
            Material(
              elevation: 8,
              color:Colors.purpleAccent,
              borderRadius: BorderRadius.circular(30),
              child: InkWell(
                onTap: (){
                  chooseImageFromGallery();
                },
                borderRadius: BorderRadius.circular(30),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 30,
                    vertical:12,
                  ),
                  child: Text(
                    "Select Image",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height:16),
            Obx(()=>ConstrainedBox(
              constraints: BoxConstraints(
                minWidth: MediaQuery.of(context).size.width * 0.7,
                maxHeight: MediaQuery.of(context).size.height * 0.6,
              ),
              child: imageSelectedByte.length > 0?
              Image.memory(imageSelectedByte,fit: BoxFit.contain,)
              :Placeholder(color: Colors.white70,),
            )),
            const SizedBox(height:16.0),
            Obx(()=> Material(
              elevation: 8,
              color: imageSelectedByte.length > 0?
              Colors.purpleAccent
              :Colors.grey,
              borderRadius: BorderRadius.circular(30),
              child: InkWell(
                onTap: (){
                  if(imageSelectedByte.length > 0)
                  {
                    //save order
                    saveNewOrderInfo();
                  }
                  else
                  {
                    Fluttertoast.showToast(msg: "Please attach the transaction proof/ Screenshot");
                  }

                },
                borderRadius: BorderRadius.circular(30),
                child: Padding(
                  padding:EdgeInsets.symmetric(
                    horizontal: 30,
                    vertical:12,
                  ),
                  child: Text(
                    "Confirmed & Proceed",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ),
            ),
          ],
        ),
      ),
    )));
  }
}
