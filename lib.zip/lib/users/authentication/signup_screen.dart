import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shopping_app/api_connection/api_connection.dart';
import 'package:shopping_app/users/authentication/login_screen.dart';
import 'package:http/http.dart' as http;

import '../model/user.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  var formKey=GlobalKey<FormState>();
  var nameController=TextEditingController();
  var emailController=TextEditingController();
  var passwordController=TextEditingController();
  var isObsecure=true.obs;
  validateUserEmail() async
  {
    try{
      var res = await http.post(
        Uri.parse(API.validateEmail),
        body:{
          'user_email':emailController.text.trim(),
        }

      );
      if(res.statusCode==200)
        {
          var resBodyOfValidateEmail = jsonDecode(res.body);
          if(resBodyOfValidateEmail['emailFound']==true)
            {
              Fluttertoast.showToast(msg: 'Email id is already in someone else use...');
            }
          else
            {
              registerAndSaveUserRecord();
            }
        }
    }
    catch(e){
      print(e.toString());
      Fluttertoast.showToast(msg: e.toString());
    }
  }
  registerAndSaveUserRecord() async
  {
    User userModel = User(
      1,
      nameController.text.trim(),
      emailController.text.trim(),
      passwordController.text.trim(),
    );
    try
    {
          var res = await http.post(
            Uri.parse(API.signUp),
            body:userModel.toJson(),
          );

          if(res.statusCode == 200)
          {
            var resBodyOfSignUp = jsonDecode(res.body);
            if(resBodyOfSignUp['success'] == true)
            {
              Fluttertoast.showToast(msg: 'Congrats, successfully Signed up.');
              setState(() {
                nameController.clear();
                emailController.clear();
                passwordController.clear();
              });
            }
            else
            {
              Fluttertoast.showToast(msg: 'Error occurred, try again.');
            }
          }
    }
    catch(e)
    {
      print(e.toString());
      Fluttertoast.showToast(msg: e.toString());
    }
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.black,
      body:LayoutBuilder(builder: (context , cons ) {
        return ConstrainedBox(
          constraints: BoxConstraints(
            minHeight: cons.maxHeight,
          ),
          child:SingleChildScrollView(
            child:Column(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height:285.0,
                  child:Image.asset('assets/images/register.jpg'),
                ),
                Padding(
                  padding:EdgeInsets.all(18),
                  child: Container(
                    decoration: BoxDecoration(
                      color:Colors.white24,
                      borderRadius: BorderRadius.all(
                        Radius.circular(60),
                      ),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 8,
                          color:Colors.black26,
                          offset: Offset(0,-3),
                        ),
                      ],
                    ),
                    child:Padding(
                      padding:EdgeInsets.fromLTRB(30, 30, 30, 8),
                      child: Column(
                        children: [
                          Form(
                            key:formKey,
                            child:Column(
                              children: [
                                TextFormField(
                                  controller: nameController,
                                  validator: (val)=> val==''?"Enter a name":null,
                                  decoration: InputDecoration(
                                    prefixIcon: const Icon(
                                      Icons.person,
                                      color:Colors.black,
                                    ),
                                    hintText: "name...",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    disabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 6,
                                    ),
                                    fillColor: Colors.white,
                                    filled: true,
                                  ),
                                ),
                                SizedBox(height:18.0),
                                TextFormField(
                                  controller: emailController,
                                  validator: (val)=> val==''?"Enter email address":null,
                                  decoration: InputDecoration(
                                    prefixIcon: const Icon(
                                      Icons.email,
                                      color:Colors.black,
                                    ),
                                    hintText: "email...",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    disabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: const BorderSide(
                                        color: Colors.white60,
                                      ),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 6,
                                    ),
                                    fillColor: Colors.white,
                                    filled: true,
                                  ),
                                ),
                                SizedBox(height:18.0),
                                Obx(()=>
                                    TextFormField(
                                      controller: passwordController,
                                      obscureText: isObsecure.value,
                                      validator: (val)=> val==''?"Enter email address":null,
                                      decoration: InputDecoration(
                                        prefixIcon: const Icon(
                                          Icons.vpn_key_sharp,
                                          color:Colors.black,
                                        ),
                                        suffixIcon: Obx(()=>
                                            GestureDetector(
                                              onTap: (){
                                                isObsecure.value=!isObsecure.value;
                                              },
                                              child:Icon(
                                                isObsecure.value?Icons.visibility_off:Icons.visibility,
                                                color:Colors.black,
                                              ),
                                            ),
                                        ),

                                        hintText: "passowrd",
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(30),
                                          borderSide: const BorderSide(
                                            color: Colors.white60,
                                          ),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(30),
                                          borderSide: const BorderSide(
                                            color: Colors.white60,
                                          ),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(30),
                                          borderSide: const BorderSide(
                                            color: Colors.white60,
                                          ),
                                        ),
                                        disabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(30),
                                          borderSide: const BorderSide(
                                            color: Colors.white60,
                                          ),
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 14,
                                          vertical: 6,
                                        ),
                                        fillColor: Colors.white,
                                        filled: true,
                                      ),
                                    ),),
                                SizedBox(height:18.0),
                                Material(
                                  color:Colors.black,
                                  borderRadius: BorderRadius.circular(30),
                                  child:InkWell(
                                    onTap: ()
                                    {
                                      if(formKey.currentState!.validate())
                                        {
                                          validateUserEmail();
                                        }
                                    },
                                    borderRadius: BorderRadius.circular(30),
                                    child:const Padding(
                                      padding:EdgeInsets.symmetric(
                                        vertical: 10,
                                        horizontal: 28,
                                      ),
                                      child:Text('SignUp',style: TextStyle(fontSize: 16,color: Colors.white),),

                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height:16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text('Already have an account?'),
                              TextButton(
                                  onPressed: (){
                                    Get.to(const LoginScreen());
                                  },
                                  child: const Text('Login here',
                                    style: TextStyle(fontSize: 16,
                                        color:Colors.black),))
                            ],
                          ),
                         ],
                      ),),
                  ),),
              ],
            ),
          ),
        );

      },),
    );
  }
}
