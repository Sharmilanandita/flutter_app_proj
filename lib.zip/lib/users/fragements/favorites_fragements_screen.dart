import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shopping_app/api_connection/api_connection.dart';
import 'package:shopping_app/users/model/favorite.dart';
import 'package:http/http.dart' as http;
import '../item/item_details_screen.dart';
import '../model/clothes.dart';
import '../userPreferences/current_user.dart';

class FavoritesFragementsScreen extends StatelessWidget {

  final currentOnlineUser = Get.put(CurrentUser());

  Future<List<Favorite>> getCurrentUserFavoriteList() async
  {
    List<Favorite> favoriteListOfCurrentUser = [];
    try
    {
      var res = await http.post(Uri.parse(API.readFavorite),
        body: {
          "user_id":currentOnlineUser.user.user_id.toString(),
        },
      );
      if(res.statusCode == 200)
      {
        var responseBodyOfCurrentUserFavoriteItems = jsonDecode(res.body);
        if(responseBodyOfCurrentUserFavoriteItems["success"] == true)
        {
          print("success..............");
          (responseBodyOfCurrentUserFavoriteItems["currentUserFavoriteData"] as List).forEach((eachRecord) {
            favoriteListOfCurrentUser.add(Favorite.fromJson(eachRecord));
          });
          print(favoriteListOfCurrentUser);
        }

      }
      else
      {
        Fluttertoast.showToast(msg: "Status code is not 200");
      }

    }
    catch(e)
    {
      Fluttertoast.showToast(msg:"Error:: " + e.toString());
    }

    return favoriteListOfCurrentUser;
  }



  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(16, 24, 8, 8),
            child: Text(
              'My Favorite List: ',
              style: TextStyle(
                fontSize: 30,
                color: Colors.purpleAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.fromLTRB(16, 24, 8, 8),
            child: Text(
              'Order these best clothes for yourself now.',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),

          const SizedBox(height:24,),

          // displaying favorite list
              favoriteListItemsDesignWidget(context),
        ],
      ),
    );
  }

  Widget favoriteListItemsDesignWidget(context) {
    return FutureBuilder(
        future: getCurrentUserFavoriteList(),
        builder: (context, AsyncSnapshot<List<Favorite>> dataSnapShot) {
          if (dataSnapShot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (dataSnapShot.data == null) {
            return const Center(
              child: Text('No favorite item found.',
              style: TextStyle(
                color: Colors.grey,
              ),),
            );
          }
          if (dataSnapShot.data!.length >= 0) {
            return ListView.builder(
              itemCount: dataSnapShot.data!.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              scrollDirection: Axis.vertical,
              itemBuilder: (context, index) {
                Favorite eachFavoriteItemsRecord = dataSnapShot.data![index];
                Clothes clickedClothItem = Clothes(
                  item_id: eachFavoriteItemsRecord.item_id,
                  name:eachFavoriteItemsRecord.name,
                  rating:eachFavoriteItemsRecord.rating,
                  tags: eachFavoriteItemsRecord.tags,
                  price: eachFavoriteItemsRecord.price,
                  sizes: eachFavoriteItemsRecord.sizes,
                  colors:eachFavoriteItemsRecord.colors,
                  description: eachFavoriteItemsRecord.description,
                  image: eachFavoriteItemsRecord.image,
                );
                return GestureDetector(
                  onTap: () {
                    Get.to(ItemDetailsScreen(itemInfo:clickedClothItem));
                  },
                  child: Container(
                    margin: EdgeInsets.fromLTRB(
                      16,
                      index == 0 ? 16 : 8,
                      16,
                      index == dataSnapShot.data!.length - 1 ? 16 : 8,
                    ),

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.black,
                        boxShadow:
                        [
                          BoxShadow(
                            offset: Offset(0, 0),
                            blurRadius: 6,
                            color: Colors.white,
                          )
                        ]
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(left: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        eachFavoriteItemsRecord.name!,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 12,right: 12),
                                      child: Text(
                                        "\$" +
                                            eachFavoriteItemsRecord.price.toString(),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.purpleAccent,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 16.0,),
                                Text(
                                  "Tags: \n" + eachFavoriteItemsRecord.tags.toString()
                                      .replaceAll("[", "")
                                      .replaceAll("]", ""),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 12,
                                  ),
                                ),

                              ],
                            ),
                          ),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.only(

                            topRight: Radius.circular(20),
                            bottomRight: Radius.circular(20),
                          ),
                          child: FadeInImage(
                            height: 130,
                            width: 130,
                            fit: BoxFit.cover,
                            placeholder: AssetImage(
                                'assets/images/place_holder.png'),
                            image: NetworkImage(
                              eachFavoriteItemsRecord.image!,
                            ),
                            imageErrorBuilder: (context, error,
                                stackTraceError) {
                              return Center(
                                child: Icon(Icons.broken_image_outlined),
                              );
                            },
                          ),
                        ),

                      ],
                    ),

                  ),
                );
              },


            );
          }

          else {
            return const Center(
              child: Text('Empty, no data found'),
            );
          }
        });
  }
}