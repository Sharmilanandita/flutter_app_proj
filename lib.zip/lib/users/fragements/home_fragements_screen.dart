import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import 'package:shopping_app/api_connection/api_connection.dart';
import 'package:shopping_app/users/cart/cart_list_screen.dart';
import 'package:shopping_app/users/item/item_details_screen.dart';
import 'package:shopping_app/users/item/search_items.dart';
import '../model/clothes.dart';

class HomeFragementsScreen extends StatelessWidget {
  TextEditingController searchController = TextEditingController();

  Future <List<Clothes>> getTrendingClothItems() async
  {
    List<Clothes> trendingClothItemsList = [];
    try {
      var res = await http.post(Uri.parse(API.getTrendingMostPopularClothes));
      if (res.statusCode == 200) {
        var responseBodyOfTrending = jsonDecode(res.body);
        if (responseBodyOfTrending["success"] == true) {
          print("yes...........success");
          (responseBodyOfTrending["clothItemsData"] as List).forEach((
              eachRecord) {
            trendingClothItemsList.add(Clothes.fromJson(eachRecord));
          });
        }
      }
      else {
        Fluttertoast.showToast(msg: "Error, Status code ore not equal to 200");
      }
    }
    catch (e) {
      print("Error:: " + e.toString());
    }
    return trendingClothItemsList;
  }

  Future <List<Clothes>> getAllClothItems() async
  {
    List<Clothes> allClothItemsList = [];
    try {
      var res = await http.post(Uri.parse(API.getAllClothes));
      if (res.statusCode == 200) {
        var responseBodyOfAllClothes = jsonDecode(res.body);
        if (responseBodyOfAllClothes["success"] == true) {
          print("yes...........success");
          (responseBodyOfAllClothes["clothItemsData"] as List).forEach((
              eachRecord) {
            allClothItemsList.add(Clothes.fromJson(eachRecord));
          });
        }
      }
      else {
        Fluttertoast.showToast(msg: "Error, Status code os not equal to 200");
      }
    }
    catch (e) {
      print("Error:: " + e.toString());
    }
    return allClothItemsList;
  }


  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child:
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 16.0),
          showSearchBarWidget(),
          SizedBox(height: 24.0),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16,),
            child: Text('Trending',
              style: TextStyle(
                color: Colors.purpleAccent,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ),
          trendingMostPopularClothItemWidget(context),
          SizedBox(height: 24.0),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16,),
            child: Text('New Collections',
              style: TextStyle(
                color: Colors.purpleAccent,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ),
          allItemsWidget(context),
        ],
      ),
    );
  }

  Widget showSearchBarWidget() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 18),
      child: TextField(
        style: TextStyle(
            color: Colors.white),
        controller: searchController,
        decoration: InputDecoration(
          prefixIcon: IconButton(
            onPressed: () {
                Get.to(SearchItems(typedKeyWords:searchController.text));
            },
            icon: Icon(Icons.search,
              color: Colors.purpleAccent,
            ),

          ),
          hintText: 'Search for cloths here...',
          hintStyle: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
          suffixIcon: IconButton(
            onPressed: () {
                Get.to(CartListScreen());
            },
            icon: Icon(Icons.shopping_cart,
              color: Colors.purpleAccent,
            ),

          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.purpleAccent,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.purple,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.purpleAccent,
            ),
          ),
          contentPadding: EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 8
          ),

        ),
      ),
    );
  }

  Widget trendingMostPopularClothItemWidget(context) {
    return FutureBuilder(
      future: getTrendingClothItems(),
      builder: (context, AsyncSnapshot<List<Clothes>> dataSnapShot) {
        if (dataSnapShot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }
        if (dataSnapShot.data == null) {
          return const Center(
            child: Text('Trending item not found.'),
          );
        }
        if (dataSnapShot.data!.length >= 0) {
          return SizedBox(
              height: 260,

              child: ListView.builder(
                itemCount: dataSnapShot.data!.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, int index) {
                  Clothes eachClothItemData = dataSnapShot.data![index];
                  return GestureDetector(
                    onTap: () {
                        Get.to(ItemDetailsScreen(itemInfo:eachClothItemData));
                    },
                    child: Container(
                      width: 200,

                      margin: EdgeInsets.fromLTRB(
                        index == 0 ? 16 : 8,
                        10,
                        index == dataSnapShot.data!.length - 1 ? 16 : 8,
                        10,
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.black,
                          boxShadow:
                          [
                            BoxShadow(
                              offset: Offset(0, 3),
                              blurRadius: 6,
                              color: Colors.grey,
                            )
                          ]
                      ),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(22),
                              topRight: Radius.circular(22),
                            ),
                            child: FadeInImage(
                              height: 150,
                              width: 200,
                              fit: BoxFit.cover,
                              placeholder: AssetImage(
                                  'assets/images/place_holder.png'),
                              image: NetworkImage(
                                eachClothItemData.image!,
                              ),
                              imageErrorBuilder: (context, error,
                                  stackTraceError) {
                                return Center(
                                  child: Icon(Icons.broken_image_outlined),
                                );
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        eachClothItemData.name!,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 10,),
                                    Text(
                                      eachClothItemData.price.toString(),
                                      style: TextStyle(
                                        color: Colors.purpleAccent,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 8.0,),
                                Row(
                                  children: [
                                    RatingBar.builder(
                                      initialRating: eachClothItemData.rating!,
                                      minRating: 1,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 5,
                                      itemBuilder: (context, c) =>
                                          Icon(
                                            Icons.star,
                                            color: Colors.amber,

                                          ),
                                      onRatingUpdate: (updateRating) {

                                      },
                                      ignoreGestures: true,
                                      unratedColor: Colors.grey,
                                      itemSize: 20,
                                    ),
                                    SizedBox(width: 8,),
                                    Text(
                                      "(" +
                                          eachClothItemData.rating.toString() +
                                          ")",
                                      style: TextStyle(
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),


                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              )
          );
        }
        else {
          return const Center(
            child: Text('Empty, no data found'),
          );
        }
      },
    );
  }

  Widget allItemsWidget(context) {
    return FutureBuilder(
        future: getAllClothItems(),
        builder: (context, AsyncSnapshot<List<Clothes>> dataSnapShot) {
          if (dataSnapShot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (dataSnapShot.data == null) {
            return const Center(
              child: Text('Trending item not found.'),
            );
          }
          if (dataSnapShot.data!.length >= 0) {
            return ListView.builder(
              itemCount: dataSnapShot.data!.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              scrollDirection: Axis.vertical,
              itemBuilder: (context, index) {
                Clothes eachClothItemsRecord = dataSnapShot.data![index];
                return GestureDetector(
                  onTap: () {
                    Get.to(ItemDetailsScreen(itemInfo:eachClothItemsRecord));
                  },
                  child: Container(
                    margin: EdgeInsets.fromLTRB(
                      16,
                      index == 0 ? 16 : 8,
                      16,
                      index == dataSnapShot.data!.length - 1 ? 16 : 8,
                    ),

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.black,
                        boxShadow:
                        [
                          BoxShadow(
                            offset: Offset(0, 0),
                            blurRadius: 6,
                            color: Colors.white,
                          )
                        ]
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(left: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        eachClothItemsRecord.name!,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 12,right: 12),
                                      child: Text(
                                        "\$" +
                                            eachClothItemsRecord.price.toString(),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.purpleAccent,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 16.0,),
                                Text(
                                 "Tags: \n" + eachClothItemsRecord.tags.toString()
                                      .replaceAll("[", "")
                                      .replaceAll("]", ""),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 12,
                                  ),
                                ),

                              ],
                            ),
                          ),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.only(

                            topRight: Radius.circular(20),
                            bottomRight: Radius.circular(20),
                          ),
                          child: FadeInImage(
                            height: 130,
                            width: 130,
                            fit: BoxFit.cover,
                            placeholder: AssetImage(
                                'assets/images/place_holder.png'),
                            image: NetworkImage(
                              eachClothItemsRecord.image!,
                            ),
                            imageErrorBuilder: (context, error,
                                stackTraceError) {
                              return Center(
                                child: Icon(Icons.broken_image_outlined),
                              );
                            },
                          ),
                        ),

                      ],
                    ),

                  ),
                );
              },


            );
          }

          else {
            return const Center(
              child: Text('Empty, no data found'),
            );
          }
        });
  }
}
