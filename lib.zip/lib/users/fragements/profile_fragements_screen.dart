import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shopping_app/users/authentication/login_screen.dart';
import 'package:shopping_app/users/userPreferences/current_user.dart';
import 'package:shopping_app/users/userPreferences/user_preferences.dart';

class ProfileFragementsScreen extends StatelessWidget {
  final CurrentUser _currentUser = Get.put(CurrentUser());
  signOutUser() async
  {
    var resultResponse = await Get.dialog(
      AlertDialog(
      backgroundColor: Colors.grey,
      title: Text(
        'Logout',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
        content: Text(
            'Are you sure? \nyou want to logout?'),
        actions: [
          TextButton(
              onPressed: (){
                Get.back();
              },
              child: Text(
                'No',
                style: TextStyle(
                  color: Colors.black,
                ),
              ),
          ),
          TextButton(
            onPressed: (){
              Get.back(result: "loggedOut");
            },
            child: Text(
              'Yes',
              style: TextStyle(
                color: Colors.black,
              ),
            ),
          )
        ],
      ),
    );
      if(resultResponse == "loggedOut")
      {
        RememberUserPrefs.removeUserInfo()
            .then((value)
            {
              Get.off(const LoginScreen());
            }
        );
      }

  }
Widget userInfoItemProfile(IconData iconData,String userData)
{

  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(12),
      color:Colors.grey,
    ),
    padding:
      EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
    child: Row(
      children: [
        Icon(
          iconData,
          size: 30,
          color:Colors.black,
        ),
        SizedBox(width:16.0),
        Text(
          userData,
          style: TextStyle(
            fontSize: 15,
          ),
        ),
      ],
    ),
  );
}
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding:EdgeInsets.all(32),
      children:[

        Center(
          child:Image.asset(
              "assets/images/women.png",
              width:240.0),
        ),

        const SizedBox(height:20.0),
        userInfoItemProfile(Icons.person,_currentUser.user.user_name),
        const SizedBox(height:20.0),
        userInfoItemProfile(Icons.email,_currentUser.user.user_email),
        const SizedBox(height:20.0),

        Center(
          child:Material(
            color:Colors.redAccent,
            borderRadius: BorderRadius.circular(8),
            child:InkWell(
              onTap: (){
                signOutUser();
              },
              borderRadius: BorderRadius.circular(32),
              child:Padding(
                padding:EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical:12,
                ),
                child:Text(
                    'Sign Out',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                )

              ),
            ),

          ),
        ),
      ]
    );
   }
}