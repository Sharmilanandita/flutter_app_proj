

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import 'package:shopping_app/api_connection/api_connection.dart';
import 'package:shopping_app/users/cart/cart_list_screen.dart';
import 'package:shopping_app/users/controllers/item_details_controllers.dart';
import 'package:shopping_app/users/userPreferences/current_user.dart';

import '../model/clothes.dart';

class ItemDetailsScreen extends StatefulWidget {
final Clothes? itemInfo;
ItemDetailsScreen({this.itemInfo});
  @override
  State<ItemDetailsScreen> createState() => _ItemDetailsScreenState();
}

class _ItemDetailsScreenState extends State<ItemDetailsScreen> {
  final itemDetailsController = Get.put(ItemDetailsController());
  final currentOnlineUser = Get.put(CurrentUser());
  addItemToCart() async
  {
    try {
      var res = await http.post(Uri.parse(API.addToCart),
        body: {
        "user_id":currentOnlineUser.user.user_id.toString(),
        "item_id":widget.itemInfo!.item_id.toString(),
        "quantity":itemDetailsController.quantity.toString(),
        "color":widget.itemInfo!.colors![itemDetailsController.color],
        "size":widget.itemInfo!.sizes![itemDetailsController.size],
        },

      );
      if (res.statusCode == 200) {
        var resBodyOfAddCart = jsonDecode(res.body);
        if (resBodyOfAddCart['success'] == true) {
          Fluttertoast.showToast(msg: 'Items successfully added to cart.');
         }
        else {
          Fluttertoast.showToast(msg: 'Error items not added to cart.');
        }
      }
      else
        {
          Fluttertoast.showToast(msg: 'status code is not 200.');
        }
    }
    catch(e)
    {
      print("Error:: "+e.toString());
    }
  }

  validateFavoriteList() async
  {
    try
    {
      var res = await http.post(Uri.parse(API.validateFavorite),
        body: {
          "user_id":currentOnlineUser.user.user_id.toString(),
          "item_id":widget.itemInfo!.item_id.toString(),
        },

      );

      if (res.statusCode == 200) {
        var resBodyOfValidateFavorite = jsonDecode(res.body);
        if (resBodyOfValidateFavorite['favoriteFound'] == true) {
          itemDetailsController.setIsFavoriteItem(true);
        }
        else {
          itemDetailsController.setIsFavoriteItem(false);
        }
      }
      else
      {
        Fluttertoast.showToast(msg: 'status code is not 200.');
      }


    }
    catch(e)
    {
      print("Error:: " + e.toString());
    }
  }


  addItemToFavoriteList() async
  {
    try
    {
      var res = await http.post(Uri.parse(API.addFavorite),
        body: {
          "user_id":currentOnlineUser.user.user_id.toString(),
          "item_id":widget.itemInfo!.item_id.toString(),
        },

      );

      if (res.statusCode == 200) {
        var resBodyOfAddFavorite = jsonDecode(res.body);
        if (resBodyOfAddFavorite['success'] == true) {
          Fluttertoast.showToast(msg: 'Items successfully is saved to Favorite List.');
          validateFavoriteList();
        }
        else {
          Fluttertoast.showToast(msg: 'Error items not saved to Favorite List.');
        }
      }
      else
      {
        Fluttertoast.showToast(msg: 'status code is not 200.');
      }


    }
    catch(e)
    {
      print("Error:: " + e.toString());
    }
  }

  deleteItemFromFavoriteList() async
  {
    try
    {
      var res = await http.post(Uri.parse(API.deleteFavorite),
        body: {
          "user_id":currentOnlineUser.user.user_id.toString(),
          "item_id":widget.itemInfo!.item_id.toString(),
        },

      );

      if (res.statusCode == 200) {
        var resBodyOfDeleteFavorite = jsonDecode(res.body);
        if (resBodyOfDeleteFavorite['success'] == true) {
          Fluttertoast.showToast(msg: 'Items successfully is deleted from Favorite List.');
          validateFavoriteList();
        }
        else {
          Fluttertoast.showToast(msg: 'Error items not deleted from Favorite List.');
        }
      }
      else
      {
        Fluttertoast.showToast(msg: 'status code is not 200.');
      }


    }
    catch(e)
    {
      print("Error:: " + e.toString());
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    validateFavoriteList();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body:
        Stack(
          children: [
            FadeInImage(
              height: MediaQuery.of(context).size.height*0.5,
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.cover,
              placeholder: AssetImage(
                  'assets/image/place_holder.png'),
              image: NetworkImage(
                widget.itemInfo!.image!,
              ),
              imageErrorBuilder: (context, error,
                  stackTraceError) {
                return Center(
                  child: Icon(Icons.broken_image_outlined),
                );
              },
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child:itemInfoWidget(),
            ),
            Positioned(
              top: MediaQuery.of(context).padding.top,
              left: 0,
              right: 0,
              child:Container(
                color: Colors.transparent,
                child: Row(
                  children: [
                    IconButton(
                      onPressed: (){
                        Get.back();
                      },
                      icon: Icon(Icons.arrow_back,
                            color: Colors.purpleAccent,

                      ),
                    ),
                    const Spacer(),
                    Obx(()=>
                        IconButton(
                          onPressed: (){
                            if(itemDetailsController.isFavorite)
                            {
                              // delete items from favourite
                              deleteItemFromFavoriteList();
                            }
                            else
                            {
                              //save items to user favourite
                              addItemToFavoriteList();
                            }
                          },
                          icon: Icon(itemDetailsController.isFavorite?
                          Icons.bookmark
                          :Icons.bookmark_border_outlined,
                          color: Colors.purpleAccent,
                          ),
                        ),

                    ),
                    IconButton(
                      onPressed: (){
                        Get.to(CartListScreen());
                      },
                      icon: Icon(Icons.shopping_cart,
                        color: Colors.purpleAccent,

                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
    );
  }
  itemInfoWidget()
  {
    return Container(
      height:MediaQuery.of(Get.context!).size.height*0.6,
      width: MediaQuery.of(Get.context!).size.width,
      decoration: BoxDecoration(
        color:Colors.black,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            offset: Offset(0,-3),
            blurRadius: 6,
            color: Colors.purpleAccent,
          ),
        ],
      ),
      padding: EdgeInsets.symmetric(horizontal: 16),
      child:SingleChildScrollView(
        child:Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height:18.0,),
            Center(
              child:Container(
                height: 8,
                width: 140,
                decoration: BoxDecoration(
                  color:Colors.purpleAccent,
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
            SizedBox(height: 30,),
            Text(
              widget.itemInfo!.name!,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.purpleAccent,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10,),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child:Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Row(
                          children: [
                            RatingBar.builder(
                              initialRating: widget.itemInfo!.rating!,
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemCount: 5,
                              itemBuilder: (context, c) =>
                                  Icon(
                                    Icons.star,
                                    color: Colors.amber,

                                  ),
                              onRatingUpdate: (updateRating) {

                              },
                              ignoreGestures: true,
                              unratedColor: Colors.grey,
                              itemSize: 20,
                            ),
                            const SizedBox(width: 8,),
                            Text(
                              "(" +
                                  widget.itemInfo!.rating.toString() +
                                  ")",
                              style: TextStyle(
                                color: Colors.purpleAccent,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height:10),
                        Text(
                          widget.itemInfo!.tags.toString().replaceAll("[", "").replaceAll("]", ""),
                          maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                          ),
                        ),
                      const SizedBox(height:16),
                      Text(
                        "\$" +
                            widget.itemInfo!.price.toString(),
                        maxLines: 1,
                        style: TextStyle(
                          color: Colors.purpleAccent,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                    ],
                  ),
                ),
                Obx(() => Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: (){
                        itemDetailsController.setQuantityItem(itemDetailsController.quantity + 1);
                      },
                      icon:Icon(Icons.add_circle_outline,color: Colors.white,),
                    ),
                    Text(
                      itemDetailsController.quantity.toString(),
                      style: TextStyle(
                        fontSize: 20,
                        color:Colors.purpleAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: (){
                        if(itemDetailsController.quantity-1>=1) {
                          itemDetailsController.setQuantityItem(
                              itemDetailsController.quantity - 1);
                        }
                        else
                        {
                          Fluttertoast.showToast(msg: "Quantity should be 1 or atleast greater than 1");
                        }
                      },
                      icon:Icon(Icons.remove_circle_outline,color: Colors.white,),
                    ),
                  ],
                ))
             ],
            ),

            const Text(
              'Size:',
              style: TextStyle(
                fontSize: 18,
                color:Colors.purpleAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height:8.0,),
            Wrap(
              runSpacing: 8,
              spacing: 8,
              children: List.generate(widget.itemInfo!.sizes!.length, (index)  {
                return Obx(()=> GestureDetector(
                onTap: (){
                      itemDetailsController.setSizeItem(index);
                    },
                  child: Container(
                    height:35,
                    width: 60,
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 2,
                      color: itemDetailsController.size == index?
                           Colors.transparent
                          :Colors.grey,
                    ),
                      color: itemDetailsController.size == index?
                          Colors.purpleAccent.withOpacity(0.4)
                          :Colors.black,
                  ),
                    alignment: Alignment.center,
                    child: Text(
                      widget.itemInfo!.sizes![index].replaceAll("[", "").replaceAll("]", ""),
                      style: TextStyle(
                        fontSize: 16,
                        color:Colors.grey[700],
                      ),
                    ),
                )
                ));
              })
            ),
            SizedBox(height:20),
            const Text(
              'Colors:',
              style: TextStyle(
                fontSize: 18,
                color:Colors.purpleAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height:8.0,),
            Wrap(
                runSpacing: 8,
                spacing: 8,
                children: List.generate(widget.itemInfo!.colors!.length, (index)  {
                  return Obx(()=> GestureDetector(
                      onTap: (){
                          itemDetailsController.setColorItem(index);
                      },
                      child: Container(
                        height:35,
                        width: 60,
                        decoration: BoxDecoration(
                          border: Border.all(
                            width: 2,
                            color: itemDetailsController.color == index?
                            Colors.transparent
                                :Colors.grey,
                          ),
                          color: itemDetailsController.color == index?
                          Colors.purpleAccent.withOpacity(0.4)
                              :Colors.black,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          widget.itemInfo!.colors![index].replaceAll("[", "").replaceAll("]", ""),
                          style: TextStyle(
                            fontSize: 16,
                            color:Colors.grey[700],
                          ),
                        ),
                      )
                  ));
                })
            ),
            SizedBox(height:20.0,),
            const Text(
              'Description:',
              style: TextStyle(
                fontSize: 18,
                color:Colors.purpleAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height:8.0,),
            Text(
              widget.itemInfo!.description!,
              textAlign: TextAlign.justify,
              style: TextStyle(
                color:Colors.grey,
              ),

            ),
            SizedBox(height:30),
            Material(
              color: Colors.purpleAccent,
              borderRadius: BorderRadius.circular(10),
              elevation: 4,
              child:InkWell(
                onTap: (){
                  addItemToCart();
                },
                borderRadius: BorderRadius.circular(10),
                child:Container(
                  height:50,
                  alignment: Alignment.center,
                  child:Text('Add to cart',
                    style: TextStyle(
                        fontSize: 20,
                        color:Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height:30),

          ],
        ),
      ),
    );
  }
}
