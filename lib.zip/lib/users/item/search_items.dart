import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shopping_app/api_connection/api_connection.dart';

import '../cart/cart_list_screen.dart';
import '../model/clothes.dart';
import 'package:http/http.dart' as http;

import 'item_details_screen.dart';


class SearchItems extends StatefulWidget {

  final String? typedKeyWords;
  SearchItems({this.typedKeyWords});

  @override
  State<SearchItems> createState() => _SearchItemsState();
}

class _SearchItemsState extends State<SearchItems> {
  TextEditingController searchController = TextEditingController();

  Future<List<Clothes>> readSearchRecordsFound() async
  {
    List<Clothes> clothesSearchList = [];
    if(searchController.text!="") {
      try
      {
        var res = await http.post(Uri.parse(API.searchItems),
          body: {
            "typedKeyWords":searchController.text,
          },
        );
        if(res.statusCode == 200)
        {
          var responseBodyOfSearchItems = jsonDecode(res.body);
          if(responseBodyOfSearchItems["success"] == true)
          {
            print("success..............");
            (responseBodyOfSearchItems["itemsFoundData"] as List).forEach((eachRecord) {
              clothesSearchList.add(Clothes.fromJson(eachRecord));
            });

          }

        }
        else
        {
          Fluttertoast.showToast(msg: "Status code is not 200");
        }

      }
      catch(e)
      {
        Fluttertoast.showToast(msg:"Error:: " + e.toString());
      }

    }
    return clothesSearchList;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    searchController.text = widget.typedKeyWords!;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.white24,
        title: showSearchBarWidget(),
        titleSpacing: 0,
        leading: IconButton(
          onPressed: (){
            Get.back();
          },
          icon: Icon(
            Icons.arrow_back,
            color: Colors.purpleAccent,
          ),
        ),
      ),
      body: SingleChildScrollView(
      child: searchItemsDesignWidget(context),
    ));
  }
  Widget showSearchBarWidget() {


    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 18),
      child: TextField(
        style: TextStyle(
            color: Colors.white),
        controller: searchController,
        decoration: InputDecoration(
          prefixIcon: IconButton(
            onPressed: () {
                setState(() {

                });
            },
            icon: Icon(Icons.search,
              color: Colors.purpleAccent,
            ),

          ),
          hintText: 'Search for cloths here...',
          hintStyle: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
          suffixIcon: IconButton(
            onPressed: () {
              searchController.clear();
              setState(() {

              });
            },
            icon: Icon(Icons.close,
              color: Colors.purpleAccent,
            ),

          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.purpleAccent,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.purple,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.purpleAccent,
            ),
          ),
          contentPadding: EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 8
          ),

        ),
      ),
    );
  }
  Widget searchItemsDesignWidget(context) {
    return FutureBuilder(
        future: readSearchRecordsFound(),
        builder: (context, AsyncSnapshot<List<Clothes>> dataSnapShot) {
          if (dataSnapShot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (dataSnapShot.data == null) {
            return const Center(
              child: Text('Trending item not found.'),
            );
          }
          if (dataSnapShot.data!.length >= 0) {
            return ListView.builder(
              itemCount: dataSnapShot.data!.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              scrollDirection: Axis.vertical,
              itemBuilder: (context, index) {
                Clothes eachClothItemsRecord = dataSnapShot.data![index];
                return GestureDetector(
                  onTap: () {
                    Get.to(ItemDetailsScreen(itemInfo:eachClothItemsRecord));
                  },
                  child: Container(
                    margin: EdgeInsets.fromLTRB(
                      16,
                      index == 0 ? 16 : 8,
                      16,
                      index == dataSnapShot.data!.length - 1 ? 16 : 8,
                    ),

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.black,
                        boxShadow:
                        [
                          BoxShadow(
                            offset: Offset(0, 0),
                            blurRadius: 6,
                            color: Colors.white,
                          )
                        ]
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(left: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        eachClothItemsRecord.name!,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 12,right: 12),
                                      child: Text(
                                        "\$" +
                                            eachClothItemsRecord.price.toString(),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.purpleAccent,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 16.0,),
                                Text(
                                  "Tags: \n" + eachClothItemsRecord.tags.toString()
                                      .replaceAll("[", "")
                                      .replaceAll("]", ""),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 12,
                                  ),
                                ),

                              ],
                            ),
                          ),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.only(

                            topRight: Radius.circular(20),
                            bottomRight: Radius.circular(20),
                          ),
                          child: FadeInImage(
                            height: 130,
                            width: 130,
                            fit: BoxFit.cover,
                            placeholder: AssetImage(
                                'assets/images/place_holder.png'),
                            image: NetworkImage(
                              eachClothItemsRecord.image!,
                            ),
                            imageErrorBuilder: (context, error,
                                stackTraceError) {
                              return Center(
                                child: Icon(Icons.broken_image_outlined),
                              );
                            },
                          ),
                        ),

                      ],
                    ),

                  ),
                );
              },


            );
          }

          else {
            return const Center(
              child: Text('Empty, no data found'),
            );
          }
        });
  }
}
